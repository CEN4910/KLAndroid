package com.lb.UCFKnightsLive.data;

/**
 * Created by echessa on 1/13/17.
 */
public final class Config {

    private Config() {
    }

    public static final String YOUTUBE_API_KEY = "AIzaSyAoNsVsB0WInmFNjMghiXRT761sH2BkN7c";

}